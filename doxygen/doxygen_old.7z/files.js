var files =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "SynchrotronComponent.hpp", "_synchrotron_component_8hpp.html", [
      [ "Mutex", "class_synchrotron_1_1_mutex.html", "class_synchrotron_1_1_mutex" ],
      [ "LockBlock", "class_synchrotron_1_1_lock_block.html", "class_synchrotron_1_1_lock_block" ],
      [ "SynchrotronComponent", "class_synchrotron_1_1_synchrotron_component.html", "class_synchrotron_1_1_synchrotron_component" ]
    ] ]
];