var hierarchy =
[
    [ "Synchrotron::LockBlock", "class_synchrotron_1_1_lock_block.html", null ],
    [ "Synchrotron::Mutex", "class_synchrotron_1_1_mutex.html", [
      [ "Synchrotron::SynchrotronComponent< bit_width >", "class_synchrotron_1_1_synchrotron_component.html", null ]
    ] ]
];