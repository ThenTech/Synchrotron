var annotated_dup =
[
    [ "Synchrotron", "namespace_synchrotron.html", "namespace_synchrotron" ]
];